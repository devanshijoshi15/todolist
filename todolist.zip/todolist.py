import pickle
from tkinter import *
from tkinter import messagebox
import tkinter

def newTask():
    task = my_entry.get()
    if task != "":
        lb.insert(END, task)
        my_entry.delete(0, "end")
    else:
        messagebox.showwarning("warning", "Please enter some task.")

def deleteTask():
    lb.delete(ANCHOR)

def saveTask():
    tasks = lb.get(0, lb.size())
    pickle.dump(tasks, open("task.dat", "wb"))

def loadTask():
    tasks = pickle.load("task.dat" ,"rb"())
    for task in tasks:
        lb.insert(tkinter.END, task)

def clearTask():
    lb.delete(0, "end")
    
ws = Tk()
ws.title("TO-DO LIST")
ws.geometry('800x550+800+300')
ws.config(bg='#4a7a8c')
ws.resizable(width=False, height=False)

#Heading Label
Label(ws, text="MY TO-DO LIST", bg='pink', font=("Comic Sans MS", 15), wraplength=300).place(x=290, y=0)

frame = Frame(ws)
frame.pack(pady=50)

lb = Listbox(
    frame,
    width=30,
    height=8,
    font=('Times', 18),
    bd=0,
    fg='#464646',
    highlightthickness=0,
    selectbackground='#a6a6a6',
    activestyle="none",
    
)
lb.pack(side=LEFT, fill=BOTH)

task_list = [
    'Eat apple',
    'drink water',
    'go gym',
    'write software',
    'write documentation',
    'take a nap',
    'Learn something',
    'paint canvas'
    ]

for item in task_list:
    lb.insert(END, item)

sb = Scrollbar(frame)
sb.pack(side=RIGHT, fill=BOTH)

lb.config(yscrollcommand=sb.set)
sb.config(command=lb.yview)

my_entry = Entry(
    ws,
    font=('times', 24)
    )

my_entry.pack(pady=20)

button_frame = Frame(ws)
button_frame.pack(pady=20)

addTask_btn = Button(
    button_frame,
    text='Add Task',
    font=('times 14'),
    bg='#c5f776',
    padx=20,
    pady=10,
    command=newTask
)
addTask_btn.pack(fill=BOTH, expand=True, side=LEFT)

delTask_btn = Button(
    button_frame,
    text='Delete Task',
    font=('times 14'),
    bg='#49A',
    padx=20,
    pady=10,
    command=deleteTask
)
delTask_btn.pack(fill=BOTH, expand=True, side=LEFT)

clearTask_btn = Button(
    button_frame,
    text='Clear Task',
    font=('Bahnschrift 14'),
    bg='#ff8b61',
    padx=20,
    pady=10,
    command=clearTask
)
clearTask_btn.pack(fill=BOTH, expand=True, side=LEFT)

saveTask_btn = Button(
    button_frame,
    text='Save Task',
    font=('Bahnschrift 14'),
    bg='yellow',
    padx=20,
    pady=10,
    command=saveTask
)
saveTask_btn.pack(fill=BOTH, expand=True, side=LEFT)

loadTask_btn = Button(
    button_frame,
    text='Load Task',
    font=('Bahnschrift 14'),
    bg='Lightgreen',
    padx=20,
    pady=10,
    command=loadTask

)
loadTask_btn.pack(fill=BOTH, expand=True, side=LEFT)

ws.mainloop()
